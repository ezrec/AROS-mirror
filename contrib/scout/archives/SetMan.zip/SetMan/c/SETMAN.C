
/*
   2.0  : Project taken over by Eric Sauvageau.
          Recompiled with SAS/C 6.58
          1.3 support dropped.
          Added $VER string


   2.1  : Would SetIoErr() after closing DOSBase if failing to create pool
          From now, the VERSION constant is ONLY used for the structure.
          So SetMan 2.1 still uses the 2.0 struct format, hence the
          struct and any check are done on "2.0".

*/


#include <exec/execbase.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <exec/types.h>
#include <exec/memory.h>
#include <libraries/dosextens.h>
#include <proto/exec.h>
#include <proto/dos.h>
#include "setman.h"

UBYTE versionstring20[] = "\0$VER: SetMan 2.1 (21.5.98)";

struct ExecBase *SysBase;
struct DosLibrary *DOSBase;

APTR mempool;
struct mymsgport mp;



void * __asm AsmCreatePool(register __d0 ULONG,
                                   register __d1 ULONG,
                                   register __d2 ULONG,
                                   register __a6 struct ExecBase *);

void * __asm AsmAllocPooled(register __a0 void *,
                                    register __d0 ULONG,
                                    register __a6 struct ExecBase *);

void __asm AsmDeletePool(register __a0 void *,
                                 register __a6 struct ExecBase *);

void __asm AsmFreePooled(register __a0 void *,
                                 register __a1 void *,
                                 register __d0 ULONG,
                                 register __a6 struct ExecBase *);


struct SetNode *CreateSetNode(struct Library *lib,WORD off,ULONG (*fun)());
VOID GetTaskName(UBYTE *buff,struct Task *task);
struct SetNode *findsetnode(struct Library *lib,WORD off,ULONG fun);
struct SetNode *findjmpnode(struct Library *lib,WORD off,ULONG jmp);
struct SetNode *findduplicatenode(struct Library *lib,WORD off,ULONG fun);
LONG __saveds __asm PatchSetFunction(register __a1 struct Library *lib,register __a0 WORD off,register __d0 ULONG (*fun)(),register __a6 struct Library *libbase);
LONG __asm (*TrueSetFunction)(register __a1 struct Library *lib,register __a0 WORD off,register __d0 ULONG (*fun)(),register __a6 struct Library *libbase);



LONG __stdargs __entrypoint(VOID)
{
SysBase = *((struct ExecBase **)4);
if (!(DOSBase = (struct DosLibrary *)OpenLibrary("dos.library",37)))
	return(RETURN_FAIL);


Forbid();

if (FindPort(setmanport))
{
	Printf("SetMan already installed.\nUse SetManager to interface with the function list.\n");
}
else
{

   if (!(mempool = AsmCreatePool( (MEMF_PUBLIC|MEMF_CLEAR), (sizeof(struct SetNode)*50),sizeof(struct SetNode),SysBase)))
   {
      SetIoErr(ERROR_NO_FREE_STORE);
      CloseLibrary(DOSBase);
      return(RETURN_FAIL);
   }

	strcpy(mp.version,VERSION);
	InitSemaphore(&mp.mysemaphore);
	NewList((struct List *)&mp.list);

	mp.msgport.mp_Node.ln_Name = setmanport;
	mp.msgport.mp_Node.ln_Type = NT_MSGPORT;
	mp.msgport.mp_Flags = PA_IGNORE;
	AddPort((struct MsgPort *)&mp);

	TrueSetFunction = (LONG __asm (*)())SetFunction(SysBase,SFOFFSET,(ULONG (*)())PatchSetFunction);

   Printf("SetMan V2.1 Copyright � 1991-1994 by Nicola Salmoria\nCopyright � 1997-98 by Eric Sauvageau\n");

	/* now we clear the pointer to our segment so CLI won't UnloadSeg() us */
	((struct CommandLineInterface *)BADDR(((struct Process *)FindTask(NULL))->pr_CLI))->cli_Module = NULL;
}

Permit();

return(RETURN_OK);
}



LONG __saveds __asm PatchSetFunction(register __a1 struct Library *lib,register __a0 WORD off,register __d0 ULONG (*fun)(),register __a6 struct Library *libbase)
{
struct SetNode *sn,*tn;
LONG result;
struct MsgPort *port;


Forbid();
//Disable();

port = FindPort(managerport);

ObtainSemaphore(&mp.mysemaphore);

if (sn = findsetnode(lib,off,(ULONG)fun))
{
	result = sn->sn_SetFunc;

	if (sn->sn_NextFunc == 0)
	{
		do
		{
			fun = (ULONG (*)())sn->sn_PrevFunc;	/* in the first loop */
						/* it should already have this value, */
						/* it's different only with dos functions */
			Remove((struct Node *)sn);

			AsmFreePooled(mempool,sn,sizeof(struct SetNode),SysBase);
			/* Free memory which could be reused from here to SetFunction() */
			/* if the function is one of the ones used here; but we are in */
			/* Forbid() and using just freed memory is quasi-legal */

         /* ES: I thought this was horrible, until told by a reliable source
                that Workbench itself does that in at least one occasion...
                So I won't bother fixing it.  Unless that's responsible
                for the PatchWork crashes? */

		} while((sn = findjmpnode(lib,off,(ULONG)fun)) && sn->sn_SetFunc == 0);

		if (sn) sn->sn_NextFunc = 0;


		(*TrueSetFunction)(lib,off,fun,libbase);
	}
	else	/* there are other nodes after this, simply disable it */
	{
		sn->sn_Jmp1 = BRACODE;
		sn->sn_SetFunc = 0;

		CacheClearU();
	}


	ReleaseSemaphore(&mp.mysemaphore);

	/* tell the manager something is happening. */
	if (port) Signal(port->mp_SigTask,1L << port->mp_SigBit);

   Permit();
}
else
{
	if (sn = findduplicatenode(lib,off,(ULONG)fun))
	{
		/* This function has already been stored in this vector, */
		/* or the same task has already modified it. Avoid the loop. */
		if (sn != (struct SetNode *)-1)
		{
			if (sn->sn_SetFunc == (ULONG)fun || !sn->sn_SetFunc)
			{
				result = sn->sn_PrevFunc;
			}
			else result = sn->sn_SetFunc;

			sn->sn_Jmp1 = JMPCODE;	/* in case it was removed */
			sn->sn_SetFunc = (ULONG)fun;	/* may already have this value */

			CacheClearU();
		}
		else result = (ULONG)fun;

		ReleaseSemaphore(&mp.mysemaphore);

		if (port) Signal(port->mp_SigTask,1L << port->mp_SigBit);
      Permit();
	}
	else if (sn = CreateSetNode(lib,off,fun))
	{
		AddTail((struct List *)&mp.list,(struct Node *)sn);
	/* here and everywhere else, I have to release BEFORE calling SetFunction() */
	/* 'cos if the modified function was ReleaseSemaphore() we could lock the machine. */

   /* ES: and what about Permit()?  Sigh. */

		ReleaseSemaphore(&mp.mysemaphore);

	/* tell the manager something is happening. */
		if (port) Signal(port->mp_SigTask,1L << port->mp_SigBit);


      Permit();
		result = (*TrueSetFunction)(lib,off,(ULONG (*)())&sn->sn_Jmp1,libbase);

		sn->sn_PrevFunc = result;

	/* since manager does not modify the list, I can scan it. Moreover, */
	/* it does not use sn_NextFunc so I can modify it. */
		if (tn = findjmpnode(lib,off,result)) tn->sn_NextFunc = (ULONG)&sn->sn_Jmp1;
	}
	else	/* let's hope this doesn't happen, or SetMan's list will be fatally confused */
	{
		ReleaseSemaphore(&mp.mysemaphore);

      Permit();
		result = (*TrueSetFunction)(lib,off,fun,libbase);
	}
}


return(result);
}



/* allocates memory for a SetNode, and initializes it with caller infos. */
struct SetNode *CreateSetNode(struct Library *lib,WORD off,ULONG (*fun)())
{
struct SetNode *sn;


if (sn = AsmAllocPooled(mempool,sizeof (struct SetNode),SysBase))

{
	sn->sn_Library = lib;
	sn->sn_Offset = off;

	sn->sn_Task = FindTask(NULL);

	GetTaskName(sn->sn_TaskName,sn->sn_Task);

	sn->sn_Jmp1 = JMPCODE;
	sn->sn_SetFunc = (ULONG)fun;
	sn->sn_Jmp2 = JMPCODE;
}

return(sn);
}



VOID GetTaskName(UBYTE *buff,struct Task *task)
{
UBYTE *tn,*tns,*endptr;
LONG len;
struct Process *proc;
struct CommandLineInterface *cli;


proc = (struct Process *)task;


/* the check for proc->pr_CLI against -1 is a patch to make programs by Preben Nielsen */
/* work correctly. Such programs want to mess the Process structure. */
if (task->tc_Node.ln_Type == NT_PROCESS && proc->pr_CLI != -1 &&
		(cli = BADDR(proc->pr_CLI)) && (endptr = BADDR(cli->cli_CommandName))
		&& endptr[0])
{
	len = *endptr++;
	tns = endptr;
}
else
{
	tns = proc->pr_Task.tc_Node.ln_Name;
	len = strlen(tns);
}

endptr = tns + len;

for (tn = tns;len--;tn++)
	if (*tn == '/' || *tn == ':') tns = tn + 1;

len = endptr - tns;
if (len > MAXTASKNAMELEN) len = MAXTASKNAMELEN;
strncpy(buff,tns,len);
buff[len] = 0;
}



struct SetNode *findsetnode(struct Library *lib,WORD off,ULONG fun)
{
struct SetNode *sn;


for (sn = (struct SetNode *)mp.list.mlh_Head;sn->sn_Node.mln_Succ;
		sn = (struct SetNode *)sn->sn_Node.mln_Succ)
{
	if (lib == sn->sn_Library && off == sn->sn_Offset &&
			(fun == sn->sn_PrevFunc))
		return(sn);
}

return(NULL);
}



struct SetNode *findjmpnode(struct Library *lib,WORD off,ULONG jmp)
{
struct SetNode *sn;


for (sn = (struct SetNode *)mp.list.mlh_Head;sn->sn_Node.mln_Succ;
		sn = (struct SetNode *)sn->sn_Node.mln_Succ)
{
	if (lib == sn->sn_Library && off == sn->sn_Offset && jmp == (ULONG)&sn->sn_Jmp1)
		return(sn);
}

return(NULL);
}



/* find if the requested function is already queued. (CodeProbe, for example) */
/* it searches not only in the SetNodeList, but also in the vector itself to */
/* see if it's already set at that value (for example: if a program restores */
/* more than once the ROM vector). In that case, returns -1. */
/* */
/* searches also if the vector has already been modified by this very task */
struct SetNode *findduplicatenode(struct Library *lib,WORD off,ULONG fun)
{
struct SetNode *sn;
struct Task *task;
UBYTE buf[22];


/* check if the vector already contains the function address */
if (*(ULONG *)((ULONG)lib + off + 2) == fun) return((struct SetNode *)-1);

task = FindTask(NULL);
GetTaskName(buf,task);


for (sn = (struct SetNode *)mp.list.mlh_Head;sn->sn_Node.mln_Succ;
		sn = (struct SetNode *)sn->sn_Node.mln_Succ)
{
	if (lib == sn->sn_Library && off == sn->sn_Offset && (fun == sn->sn_SetFunc
				|| (task == sn->sn_Task && !strcmp(buf,sn->sn_TaskName))))
		return(sn);
}

return(NULL);
}
