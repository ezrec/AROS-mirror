/*
    1.0d : CacheClearU() nei punti appropriati.
*/

/*************************************************************************

Program .......... SetManager

Version .......... 1.0

Author ........... Nicola Salmoria
                   Via Piemonte 11, 53100 Siena ITALY
                   (0577)54164

Function ......... Give a list of modified library vectors and allow to disable
                   interception routines. Need SetMan to be active.

Package .......... Aztec C Compiler V5.0a

Hardware ......... Amiga 512K, Kickstart V1.2/V1.3

Compiling ........ cc SetManager.c -3
                   ln SetManager.o -lc16

**************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <exec/execbase.h>
#include <intuition/intuition.h>
#include <intuition/intuitionbase.h>
#include <graphics/gfxbase.h>
#include <graphics/gfxmacros.h>
#include <workbench/startup.h>
#include "setman.h"


#define REVISION "d"	/* revision, version number is in setman.h */




struct LibraryInfo
{
	struct LibraryInfo *Next;	/* data are kept in a linked list */
	UBYTE	LibraryName[30];		/* library name */
	WORD Entries;			/* number of offsets stored starting from 0 */
	ULONG TotalLen;			/* total size of memory block */
	UBYTE *FunctionName[1];		/* 'Entries' pointers to names, and */
						/* following them, the actual names. */
};


extern struct ExecBase *SysBase;
struct GfxBase *GfxBase;
struct IntuitionBase *IntuitionBase;


struct mymsgport *SetManPort;
struct MsgPort *ManagerPort;

struct LibraryInfo *LibInfoList;	/* pointer to linked list of function names */

WORD NumberOfNodes;	/* number of nodes in the SetNodeList */
WORD NumberOfGadgets;	/* number of gadgets in the window */
WORD MaxChars;		/* characters to print in a single line */

struct Window *window;
struct Gadget *scrollbar[2];
struct Gadget *hidden[100];



typedef struct Gadget GADG;
typedef struct PropInfo PINF;
typedef struct Image IMGE;

#define BARINFO(x) (((PINF *)(x)->SpecialInfo))
#define BARKNOB(x) (((IMGE *)(x)->GadgetRender))




struct Window *OpenManagerWindow(VOID);
VOID MakeGadgetList(VOID);
VOID ResizeScrollBars(VOID);
VOID refreshdisplay(VOID);
WORD CountNodes(struct MinList *);
#pragma regcall(CountNodes(a0))
VOID PrintNodeList(WORD,WORD,WORD);
#pragma regcall(PrintNodeList(d0,d1,d2))
VOID PrintNode(struct SetNode *,WORD,WORD,WORD,WORD);
#pragma regcall(PrintNode(a0,d0,d1,d2,d3))
VOID PadWithSpaces(UBYTE *,WORD);
#pragma regcall(PadWithSpaces(a0,d0))
void myhextoa(UBYTE *,LONG,WORD,WORD);
#pragma regcall(myhextoa(a0,d0,d1,d2))
GADG *CreateScrollBar(struct Window *,WORD,WORD,WORD,WORD,UWORD,UWORD,UWORD,UWORD,UWORD,UWORD);
GADG *CreateHiddenGadget(struct Window *,WORD,UWORD);
#pragma regcall(CreateHiddenGadget(a0,d0,d1))
VOID FreeGadget(GADG *);
#pragma regcall(FreeGadget(a0))
ULONG MyGetMsg(struct MsgPort *,struct IntuiMessage *);
#pragma regcall(MyGetMsg(a0,a1))
ULONG BarPos(ULONG,WORD,UWORD);
#pragma regcall(BarPos(d0,d1,d2))
ULONG SetBody(ULONG,WORD);
#pragma regcall(SetBody(d0,d1))
struct LibraryInfo *ReadAllFD(VOID);
struct LibraryInfo *ReadFD(UBYTE *);
#pragma regcall(ReadFD(a0))
struct LibraryInfo *ProcessFD(UBYTE *);
#pragma regcall(ProcessFD(a0))
struct LibraryInfo *FindLibraryInfo(struct LibraryInfo *,UBYTE *);
#pragma regcall(FindLibraryInfo(a0,a1))
VOID message(UBYTE *);
#pragma regcall(message(a0))
VOID cleanup(WORD);
#pragma regcall(cleanup(d0))






VOID _main(VOID)
{
struct SetNode *sn;
struct IntuiMessage mymsg;
WORD gadsel;
WORD xstart,ystart;
ULONG recsignal,mysignal,windowsignal;
struct Process *process;

extern struct mymsgport *SetManPort;
extern struct MsgPort *ManagerPort;
extern WORD NumberOfNodes;
extern WORD NumberOfGadgets;
extern WORD MaxChars;
extern struct LibraryInfo *LibInfoList;
extern struct Window *window;
extern struct Gadget *scrollbar[2];
extern struct WBStartup *WBenchMsg;



process = (struct Process *)FindTask(NULL);

if (!process->pr_CLI)	/* from WorkBench */
{
	WaitPort(&process->pr_MsgPort);
	WBenchMsg = (struct WBStartup *)GetMsg(&process->pr_MsgPort);
}


if (!(GfxBase = (struct GfxBase *)OpenLibrary("graphics.library",0L)))
	cleanup(RETURN_FAIL);

if (!(IntuitionBase = (struct IntuitionBase *)OpenLibrary("intuition.library",33L)))
	cleanup(RETURN_FAIL);



if (!(SetManPort = (struct mymsgport *)FindPort(setmanport)))
{
	message("SetMan is not active. Run it first.");

	cleanup(RETURN_FAIL);
}

if (strcmp(SetManPort->version,VERSION))
{
	message("SetMan and SetManager are not the same version.");

	cleanup(RETURN_FAIL);
}



Forbid();

if (FindPort(managerport))
{
	Permit();

	message("SetFunction Manager already running.");

	cleanup(RETURN_WARN);
}


if (!(ManagerPort = CreatePort(managerport,0)))
{
	Permit();

	cleanup(RETURN_FAIL);
}

Permit();



LibInfoList = ReadAllFD();

if (!OpenManagerWindow()) cleanup(RETURN_FAIL);

windowsignal = 1L << window->UserPort->mp_SigBit;
mysignal = 1L << ManagerPort->mp_SigBit;


FOREVER
{
	recsignal = Wait(windowsignal | mysignal);

	if (recsignal & mysignal)
	{
		NumberOfNodes = CountNodes(&SetManPort->list);
		MakeGadgetList();

		ResizeScrollBars();

		refreshdisplay();
	}

	if (recsignal & windowsignal)
	{
		while (MyGetMsg(window->UserPort,&mymsg)) switch (mymsg.Class)
		{
		case CLOSEWINDOW:
			cleanup(RETURN_OK);
			break;
		case NEWSIZE:
			MakeGadgetList();
			ResizeScrollBars();
			refreshdisplay();
			break;
		case GADGETDOWN:
			gadsel = (((GADG *)mymsg.IAddress)->GadgetID);
			break;
		case GADGETUP:
			gadsel = (((GADG *)mymsg.IAddress)->GadgetID);

			if (gadsel >= 10)
			{
gadsel -= 10;

xstart = BarPos(70,MaxChars,BARINFO(scrollbar[1])->HorizPot);
ystart = BarPos(NumberOfNodes,NumberOfGadgets,BARINFO(scrollbar[0])->VertPot) + gadsel;

ObtainSemaphore(&SetManPort->mysemaphore);

for (sn = (struct SetNode *)SetManPort->list.mlh_Head;sn->sn_Node.mln_Succ &&
		ystart--;sn = (struct SetNode *)sn->sn_Node.mln_Succ);


if (sn->sn_SetFunc)
{
	if (sn->sn_Jmp1 == JMPCODE) sn->sn_Jmp1 = BRACODE;
	else sn->sn_Jmp1 = JMPCODE;

	if (SysBase->LibNode.lib_Version >= 37) CacheClearU();

	PrintNode(sn,xstart,MaxChars,0,gadsel);
}

ReleaseSemaphore(&SetManPort->mysemaphore);

				gadsel = 0;
			}
/* NOTE: no 'break' here. Fall down in the MOUSEMOVE case. */
		case MOUSEMOVE:
			switch (gadsel)
			{
			case 1:
				ystart = BarPos(NumberOfNodes,NumberOfGadgets,BARINFO(scrollbar[0])->VertPot);

				PrintNodeList(-1,ystart,0);

				break;
			case 2:
				if (!BARKNOB(scrollbar[1])->LeftEdge)
			/* work around the intuition bug */
					BARINFO(scrollbar[1])->HorizPot = 0;

				xstart = BarPos(70,MaxChars,BARINFO(scrollbar[1])->HorizPot);

				PrintNodeList(xstart,-1,0);

				break;
			}

			if (mymsg.Class == GADGETUP) gadsel = 0;
			break;
		}
	}
}
}





struct Window *OpenManagerWindow(VOID)
{
struct NewWindow nw;
struct Screen scrdata;
WORD FontYSize = GfxBase->DefaultFont->tf_YSize;
WORD FontXSize = GfxBase->DefaultFont->tf_XSize;
struct RastPort *rp;
extern struct Window *window;
extern WORD NumberOfNodes;
extern WORD NumberOfGadgets;
extern WORD MaxChars;
extern struct Gadget *scrollbar[2];


NumberOfNodes = CountNodes(&SetManPort->list);


if (GetScreenData(&scrdata,sizeof(struct Screen),WBENCHSCREEN,NULL))
{
	nw.MinHeight = scrdata.BarHeight + 5 * FontYSize + 11;
	if (NumberOfNodes >= 3) nw.Height = nw.MinHeight + (NumberOfNodes - 3) * FontYSize;
	else nw.Height = nw.MinHeight;
	if (nw.Height > scrdata.Height)
		nw.Height = ((scrdata.Height - scrdata.BarHeight - 11) / FontYSize)
				* FontYSize + scrdata.BarHeight + 11;
	nw.TopEdge = (scrdata.Height - nw.Height) / 2;
	nw.MaxHeight = -1;

	nw.Width = 70 * FontXSize + 22;
	if (nw.Width > scrdata.Width)
		nw.Width = ((scrdata.Width - 22) / FontXSize) * FontXSize + 22;
	nw.MaxWidth = nw.Width;
	nw.MinWidth = 32 * FontXSize + 22;
	nw.LeftEdge = (scrdata.Width - nw.Width) / 2;

	nw.DetailPen = 0;
	nw.BlockPen = 1;
	nw.IDCMPFlags = GADGETDOWN | GADGETUP | MOUSEMOVE | CLOSEWINDOW | NEWSIZE | SIZEVERIFY,
	nw.Flags = SMART_REFRESH | NOCAREREFRESH | ACTIVATE | WINDOWDRAG | WINDOWDEPTH |
				WINDOWCLOSE | WINDOWSIZING | SIZEBRIGHT | SIZEBBOTTOM,
	nw.FirstGadget = NULL;
	nw.CheckMark = NULL;
	nw.Title = "SetFunction Manager V"VERSION""REVISION,
	nw.Type = WBENCHSCREEN;
	nw.Screen = NULL;
	nw.BitMap = NULL;

	if (window = OpenWindow(&nw))
	{
		rp = window->RPort;

		MaxChars = (window->Width - window->BorderLeft - window->BorderRight) / rp->TxWidth;
		MakeGadgetList();
		scrollbar[0] = CreateScrollBar(window,-window->BorderRight + 5,window->BorderTop + 1,window->BorderRight - 8,-window->BorderTop - window->BorderBottom - 2,NULL,NULL,NULL,SetBody(NumberOfNodes,NumberOfGadgets),FREEVERT,1);
		scrollbar[1] = CreateScrollBar(window,window->BorderLeft,-window->BorderBottom + 3,-window->BorderLeft - window->BorderRight - 2,window->BorderBottom - 4,NULL,NULL,SetBody(70,MaxChars),NULL,FREEHORIZ,2);

		refreshdisplay();
	}
}

return(window);
}






/* Crea i gadget nascosti per i nomi delle funzioni. Sfrutta quelli gia` presenti. */
/* Notare che la prima volta che si chiama, NumberOfGadgets e` 0 quindi non ci sono problemi. */
VOID MakeGadgetList(VOID)
{
WORD k,y;
extern WORD NumberOfNodes;
extern WORD NumberOfGadgets;
extern struct Window *window;
struct RastPort *rp = window->RPort;
extern struct Gadget *hidden[100];


k = (window->Height - window->BorderTop - window->BorderBottom) / rp->TxHeight - 2;
if (k > NumberOfNodes) k = NumberOfNodes;

if (k < NumberOfGadgets)
{
	while (NumberOfGadgets > k)
	{
		RemoveGList(window,hidden[--NumberOfGadgets],1L);
		FreeGadget(hidden[NumberOfGadgets]);
	}
}
else if (k > NumberOfGadgets)
{
	y = window->BorderTop + (2 + NumberOfGadgets) * rp->TxHeight;

	while (NumberOfGadgets < k)
	{
		hidden[NumberOfGadgets] = CreateHiddenGadget(window,y,NumberOfGadgets + 10);
		NumberOfGadgets++;
		y += rp->TxHeight;
	}
}
}




/* ridimensiona le scroll bars dopo un resize o un cambiamento nella setnodelist */
VOID ResizeScrollBars(VOID)
{
WORD newbody;
extern WORD NumberOfNodes;
extern WORD NumberOfGadgets;
extern struct Window *window;
extern struct Gadget *scrollbar[2];


newbody = SetBody(NumberOfNodes,NumberOfGadgets);

if (newbody != BARINFO(scrollbar[0])->VertBody)
{
	RemoveGList(window,scrollbar[0],1L);
	BARINFO(scrollbar[0])->VertBody = newbody;
	AddGList(window,scrollbar[0],-1L,1L,NULL);
	RefreshGList(scrollbar[0],window,NULL,1L);
}


MaxChars = (window->Width - window->BorderLeft - window->BorderRight) / window->RPort->TxWidth;
newbody = SetBody(70,MaxChars);

if (newbody != BARINFO(scrollbar[1])->HorizBody)
{
	RemoveGList(window,scrollbar[1],1L);
	BARINFO(scrollbar[1])->HorizBody = newbody;
	AddGList(window,scrollbar[1],-1L,1L,NULL);
	RefreshGList(scrollbar[1],window,NULL,1L);
}
}





VOID refreshdisplay(VOID)
{
struct RastPort *rp = window->RPort;
WORD xstart,ystart;
extern WORD NumberOfNodes;
extern WORD NumberOfGadgets;
extern WORD MaxChars;

xstart = BarPos(70,MaxChars,BARINFO(scrollbar[1])->HorizPot);
ystart = BarPos(NumberOfNodes,NumberOfGadgets,BARINFO(scrollbar[0])->VertPot);

PrintNodeList(xstart,ystart,1);
}





WORD CountNodes(struct MinList *list)
{
struct SetNode *sn;
WORD count = 0;
extern struct mymsgport *SetManPort;

ObtainSemaphore(&SetManPort->mysemaphore);

for (sn = (struct SetNode *)list->mlh_Head;sn->sn_Node.mln_Succ;
		sn = (struct SetNode *)sn->sn_Node.mln_Succ)
	count++;

ReleaseSemaphore(&SetManPort->mysemaphore);

return(count);
}





/* se xstart o ystart == -1, la coordinata viene lasciata inalterata */
VOID PrintNodeList(WORD xstart,WORD ystart,WORD refresh)
{
WORD k;
WORD mink,maxk;
WORD first,len,xpos;
struct SetNode *sn;
extern struct Window* window;
struct RastPort *rp = window->RPort;
static WORD currentx = -1,currenty = -1;
extern struct mymsgport *SetManPort;
extern WORD NumberOfGadgets;


if (xstart == -1) xstart = currentx;
if (ystart == -1) ystart = currenty;


if (!refresh && currenty == ystart && currentx == xstart) return;


if (!refresh && currentx == xstart && (ystart - currenty < NumberOfGadgets) &&
		(currenty - ystart < NumberOfGadgets))
{
	SetWrMsk(rp,1);

	ScrollRaster(rp,0L,(ystart - currenty) * rp->TxHeight,window->BorderLeft,
			window->BorderTop + 2 * rp->TxHeight,window->BorderLeft + MaxChars * rp->TxWidth - 1,
			window->BorderTop + (NumberOfGadgets + 2) * rp->TxHeight - 1);

	SetWrMsk(rp,-1);

	if (ystart > currenty)
	{
		mink = NumberOfGadgets - ystart + currenty;
		maxk = NumberOfGadgets;
	}
	else
	{
		mink = 0;
		maxk = currenty - ystart;
	}
}
else
{
	mink = 0;
	maxk = NumberOfGadgets;
}


if (!refresh && currenty == ystart && (xstart - currentx < MaxChars) &&
		(currentx - xstart < MaxChars))
{
	SetWrMsk(rp,1);

	ScrollRaster(rp,(xstart - currentx) * rp->TxWidth,0,window->BorderLeft,
			window->BorderTop,window->BorderLeft + MaxChars * rp->TxWidth - 1,
			window->BorderTop + (NumberOfGadgets + 2) * rp->TxHeight - 1);

	SetWrMsk(rp,-1);

	if (xstart > currentx)
	{
		first = MaxChars + currentx;
		len = xstart - currentx;
		xpos = MaxChars - xstart + currentx;
	}
	else
	{
		first = xstart;
		len = currentx - xstart;
		xpos = 0;
	}
}
else
{
	first = xstart;
	xpos = 0;
	len = MaxChars;
}


if (refresh || currentx != xstart) PrintNode(0,first,len,xpos,0);


currentx = xstart;
currenty = ystart;


ObtainSemaphore(&SetManPort->mysemaphore);

for (k = 0,sn = (struct SetNode *)SetManPort->list.mlh_Head;sn->sn_Node.mln_Succ &&
		k < maxk;sn = (struct SetNode *)sn->sn_Node.mln_Succ)
{
	if (!ystart)
	{
		if (k >= mink) PrintNode(sn,first,len,xpos,k);
		k++;
	}
	else ystart--;
}

ReleaseSemaphore(&SetManPort->mysemaphore);


if (refresh)
{
	SetAPen(rp,0L);
	SetWrMsk(rp,1);

	/* clear the bottom of the window */
	xstart = window->BorderTop + (NumberOfGadgets + 2) * (rp->TxHeight);
	ystart = window->Height - window->BorderBottom - 1;

	if (xstart <= ystart)
		RectFill(rp,window->BorderLeft,xstart,
				window->Width - window->BorderRight - 1,ystart);


	/* clear the right of the window */
	xstart = window->BorderLeft + MaxChars * rp->TxWidth - 1,
	ystart = window->Width - window->BorderRight - 1;

	if (xstart <= ystart)
		RectFill(rp,xstart,window->BorderTop,
				ystart,window->Height - window->BorderBottom - 1);

	SetWrMsk(rp,-1);
}
}




/* se 'sn' e` zero, stampa l'intestazione */
/* IMPORTANTE: questa funzione non ObtainSemaphore(). Va fatto prima di chiamarla. */
VOID PrintNode(struct SetNode *sn,WORD firstchar,WORD len,WORD xpos,WORD ypos)
{
struct LibraryInfo *libinf;
UBYTE buf[100];
WORD offs;
extern struct Window *window;
struct RastPort *rp = window->RPort;
LONG xcoord;
extern struct LibraryInfo *LibInfoList;

xcoord = window->BorderLeft + xpos * rp->TxWidth;

SetAPen(rp,1L);
SetBPen(rp,0L);
SetDrMd(rp,JAM2);

if (!sn)
{
	SetWrMsk(rp,1);
	Move(rp,xcoord,window->BorderTop + rp->TxBaseline);
	Text(rp,&("    Handler Task       Code               Function             Status ")[firstchar],len);
	Move(rp,xcoord,window->BorderTop + rp->TxBaseline + rp->TxHeight);
	Text(rp,&("-------------------- -------- ------------------------------- --------")[firstchar],len);
	SetWrMsk(rp,-1);
}
else
{
	offs = (WORD)-sn->sn_Offset / 6;

	strcpy(buf,sn->sn_TaskName);
	PadWithSpaces(buf,20);

	if (sn->sn_SetFunc)
	{
		buf[20] = ' ';
		myhextoa(&buf[21],sn->sn_SetFunc,8,'0');
		buf[29] = ' ';
		buf[30] = 0;
	}
	else strcat(buf," -------- ");

	if ((offs <= 4 && sn->sn_Library->lib_Node.ln_Type == NT_LIBRARY) ||
			(offs <= 6 && sn->sn_Library->lib_Node.ln_Type == NT_DEVICE))
	{
		static UBYTE *defnames[] = {"Open","Close","Expunge","ExtFunc","BeginIO","AbortIO"};

		strcat(buf,defnames[offs - 1]);
		strcat(buf,"() ");
		strcat(buf,sn->sn_Library->lib_Node.ln_Name);
	}
	else if ((libinf = FindLibraryInfo(LibInfoList,sn->sn_Library->lib_Node.ln_Name)) &&
			 offs <= libinf->Entries && libinf->FunctionName[offs])
	{
		strcat(buf,libinf->FunctionName[offs]);
		strcat(buf,"()");
	}
	else
	{
		buf[30] = '-';
		myhextoa(&buf[31],-sn->sn_Offset,4,'0');
		buf[35] = ' ';
		buf[36] = 0;
		strcat(buf,sn->sn_Library->lib_Node.ln_Name);
	}
	PadWithSpaces(buf,61);

	if (!sn->sn_SetFunc) strcat(buf," Removed ");
	else if (sn->sn_Jmp1 == JMPCODE) strcat(buf,"  Active ");
	else strcat(buf," Disabled");

	SetWrMsk(rp,1);
	Move(rp,xcoord,window->BorderTop + rp->TxBaseline + (2 + ypos) * rp->TxHeight);
	Text(rp,&buf[firstchar],len);
	SetWrMsk(rp,-1);
}
}






/* pad string with spaces till the length specified. NULL terminates. */
VOID PadWithSpaces(UBYTE *buf,WORD len)
{
WORD count;

buf[len] = 0;

buf += (count = strlen(buf));
count = len - count;

while (count-- > 0) *(buf++) = ' ';
}




#asm
; Convert LONG to ascii (string is *NOT* null terminated)
; myhextoa(string,value,length,pad)
; a0 = UBYTE *
; d0 = LONG value
; d1 = WORD length of string
; d2 = '0', ' ' or anything you want to be used to fill empty spaces.
;      Zero means align to the left: in this case, string IS null terminated

	xdef	_myhextoa
_myhextoa:
	movem.l	d3/d4/a2,-(sp)
	move.l	a0,a1
	move.w	d1,d4
	add.w	d1,a0
	lea	hexchars,a2
	bra	2$
1$	move.b	d0,d3
	and.w	#$f,d3
	move.b	0(a2,d3.w),d3
	move.b	d3,-(a0)
	lsr.l	#4,d0
	beq	7$
2$	dbra	d1,1$
	bra	5$
7$	tst.b	d2
	bne	4$
	sub.w	d1,d4
	bra	8$
9$	move.b	(a0)+,(a1)+
8$	dbra	d4,9$
	move.b	#0,(a1)
	bra	5$
3$	move.b	d2,-(a0)
4$	dbra	d1,3$
5$	movem.l	(sp)+,d3/d4/a2
	rts

hexchars:
	dc.b	"0123456789abcdef"
	ds	0
#endasm




/* Questa funzione alloca memoria per un gadget proporzionale e lo crea secondo */
/* i parametri specificati nella chiamata a funzione. La quantita` di memoria */
/* allocata viene memorizzata nel campo UserData per essere usata da FreeGadget(). */
/* Il gadget creato viene automaticamente aggiunto alla finestra e visualizzato. */
/* Per essere veramente completa, questa funzione dovrebbe permettere di */
/* specificare posizioni e dimensioni negative che andrebbero interpretate come */
/* relative alle dimensioni della finestra. */
GADG *CreateScrollBar(struct Window *wind,WORD x,WORD y,WORD w,WORD h,UWORD hpot,UWORD vpot,UWORD hbody,UWORD vbody,UWORD flags,UWORD id)
{
GADG *gadg;
PINF *pi;
IMGE *im;
LONG gadsize;

gadsize = sizeof(GADG) + sizeof(PINF) + sizeof(IMGE);

if (gadg = AllocMem(gadsize,MEMF_CLEAR | MEMF_PUBLIC))
{
	pi = (PINF *)(gadg + 1);
	im = (IMGE *)(pi + 1);

	if (x < 0) gadg->Flags |= GRELRIGHT;
	if (y < 0) gadg->Flags |= GRELBOTTOM;
	if (w <= 0) gadg->Flags |= GRELWIDTH;
	if (h <= 0) gadg->Flags |= GRELHEIGHT;

	if (IntuitionBase->LibNode.lib_Version < 36)
	{
		if (flags & FREEVERT)
		{
			x -= 2;
			y -= 2;
			w += 6;
			h += 4;
		}
		else
		{
			x -= 4;
			y -= 1;
			w += 8;
			h += 3;
		}
	}

	gadg->LeftEdge = x;
	gadg->TopEdge = y;
	gadg->Width = w;
	gadg->Height = h;

	gadg->Flags |= GADGHCOMP;
	gadg->Activation |= GADGIMMEDIATE | FOLLOWMOUSE | RELVERIFY;
	gadg->GadgetType = PROPGADGET;
	gadg->GadgetRender = (APTR)im;
	gadg->SpecialInfo = (APTR)pi;
	gadg->GadgetID = id;
	gadg->UserData = (APTR)gadsize;

	pi->Flags = flags | AUTOKNOB | PROPNEWLOOK;
	pi->HorizPot = hpot;
	pi->VertPot = vpot;
	pi->HorizBody = hbody;
	pi->VertBody = vbody;

	AddGList(wind,gadg,-1L,1L,NULL);
	RefreshGList(gadg,wind,NULL,1L);
}

return(gadg);
}



/* crea un gadget per la lista delle funzioni. trova da solo quel che gli serve. */
GADG *CreateHiddenGadget(struct Window *wind,WORD y,UWORD id)
{
GADG *gadg;
LONG gadsize;

gadsize = sizeof(GADG);

if (gadg = AllocMem(gadsize,MEMF_CLEAR | MEMF_PUBLIC))
{
	gadg->LeftEdge = window->BorderLeft;
	gadg->TopEdge = y;
	gadg->Width = -window->BorderLeft -window->BorderRight;
	gadg->Height = window->RPort->TxHeight;
	gadg->Flags |= GADGHCOMP | GRELWIDTH;
	gadg->Activation |= RELVERIFY;
	gadg->GadgetType = BOOLGADGET;
	gadg->GadgetID = id;
	gadg->UserData = (APTR)gadsize;

	AddGList(wind,gadg,-1L,1L,NULL);
	RefreshGList(gadg,wind,NULL,1L);
}

return(gadg);
}




/* Libera la memoria allocata per un gadget. Chiamare questa funzione solo DOPO */
/* un RemoveGList() o la chiusura della finestra!!!! */
/* E` lecito chiamare questa funzione con argomento nullo, nel qual caso si ha */
/* un ritorno immediato. */
VOID FreeGadget(GADG *gadg)
{
if (gadg) FreeMem(gadg,(LONG)gadg->UserData);
}




/* Prende un messaggio dalla MsgPort (se ce n'e` uno), e lo copia in 'msg'. */
/* Ritorna il codice del messaggio, o zero se nessuno. E` garantito che il */
/* campo msg->Class sia uguale al valore ritornato. */
/* Eventuali sequenze di messaggi MOUSEMOVE vengono ridotte a un solo messaggio. */
ULONG MyGetMsg(struct MsgPort *port,struct IntuiMessage *msg)
{
struct IntuiMessage *imsg;

do
{
	if (imsg = (struct IntuiMessage *)GetMsg(port))
	{
		if (imsg->Class != MOUSEMOVE)
			CopyMem(imsg,msg,sizeof(*msg));
		else msg->Class = MOUSEMOVE;	/* non c'e` bisogno d'altro */

		ReplyMsg((struct Message *)imsg);
	}
	else msg->Class = 0;

/* se questo e` un MOUSEMOVE e il prossimo lo stesso, leggi il prossimo */
} while (msg->Class == MOUSEMOVE && (imsg = (struct IntuiMessage *)port->mp_MsgList.
		lh_Head)->ExecMessage.mn_Node.ln_Succ && imsg->Class == MOUSEMOVE);

return(msg->Class);
}




#asm
; Questa funzione calcola la posizione indicata dalla scroll bar
;
; position = BarPos(ULONG numlines,WORD pagesize,UWORD pot)
;    D0                     D0             D1          D2
;
; numlines = numero totale di linee
; pagesize = numero di linee visualizzate sullo schermo
; pot = HorizPot o VertPot dalla struttura PropInfo

	xdef	_BarPos
_BarPos:
	movem.l	d2/d3,-(sp)

;	move.l	12(sp),d0	;se il compilatore non puo` passare parametri nei
;	move.w	16(sp),d1	;registri, togliere il punto e virgola da
;	move.w	18(sp),d2	;davanti a queste linee

	ext.l	d1	;azzera la word alta di d1 (si suppone d1 < 8000)
	sub.l	d1,d0	;d0 = numlines - pagesize = maxline
	bhi	1$	;se pagesize >= numlines,
	moveq	#0,d0	;la posizione e` per forza 0, carica in d0 e esci
	bra	5$

1$	moveq	#0,d3
	not.w	d3	;carica FFFF in d3
	divu	d3,d0	;divide maxline per FFFF
	bvc	2$	;un overflow puo` avvenire solo se d0 >= FFFF0000
	move.w	d2,d1
	swap	d1	;in tal caso, d1 = pot * 10000
	bra	3$

2$	move.w	d0,d1	;se non c'era overflow,
	swap	d0	;resto in d0 e quoziente in d1
	mulu	d2,d1	;d1 = Q * pot
3$	mulu	d2,d0	;d0 = R * pot
	divu	d3,d0	;d0 = (R * pot) / FFFF
	tst.l	d0	;se il resto e` >= 8000
	bpl	4$
	addq.w	#1,d0	;arrotonda all'intero superiore
4$	and.l	d3,d0	;elimina il resto, non ci serve piu`
	add.l	d1,d0	;somma il tutto, finito
5$	movem.l	(sp)+,d2/d3
	rts




; Questa funzione calcola il valore da mettere nel campo Body
;
; body = SetBody(ULONG numlines,WORD pagesize)
;  D0                    D0             D1
;
; numlines = numero totale di linee
; pagesize = numero di linee visualizzate sullo schermo

	xdef	_SetBody:
_SetBody:
	movem.l	d2-d3,-(sp)

;	move.l	12(sp),d0	;se il compilatore non puo` passare parametri nei
;	move.w	16(sp),d1	;registri, togliere il punto e virgola

	ext.l	d1	;questa funzione e` molto simile a SetPos(), non
	cmp.l	d0,d1	;ripetero` i commenti gia` fatti
	bcs	1$
	moveq	#-1,d0
	bra	9$
1$	move.l	d1,d2
	swap	d1
	sub.l	d2,d1
	move.l	d0,d2
	swap	d2
	tst.w	d2
	bne	2$
	divu	d0,d1
	move.l	d1,d2
	clr.w	d2
	swap	d2
	bra	7$

2$	moveq	#0,d2	;a differenza di SetPos(), qui il dividendo e` di soli
	swap	d1	;32 bit, quindi risparmio un registro (e una somma nel
	move.w	d1,d2	;ciclo) e tengo il risultato in d1 assieme a una parte
	clr.w	d1	;del divisore
	moveq	#15,d3
4$	add.l	d1,d1
	addx.l	d2,d2
	bcs	5$
	cmp.l	d2,d0
	bhi	6$
5$	sub.l	d0,d2
	addq.w	#1,d1
6$	dbf	d3,4$
7$	lsr.l	#1,d0
	cmp.l	d0,d2
	bls	8$
	addq.w	#1,d1
8$	moveq	#0,d0
	move.w	d1,d0
9$	movem.l	(sp)+,d2-d3
	rts
#endasm





struct LibraryInfo *ReadAllFD(VOID)
{
struct LibraryInfo *libinf = 0;
struct LibraryInfo **next;
struct FileInfoBlock *fib;
BPTR dir,odir;
struct Process *proc;
APTR windowptr;


proc = (struct Process *)FindTask(NULL);

windowptr = proc->pr_WindowPtr;
proc->pr_WindowPtr = (APTR)-1;	/* disable DOS requesters */

dir = Lock("FD:",ACCESS_READ);

proc->pr_WindowPtr = windowptr;

if (dir)
{
	odir = CurrentDir(dir);

	if (fib = AllocMem(sizeof(*fib),MEMF_CLEAR | MEMF_PUBLIC))
	{
		if (Examine(dir,fib))
		{
			next = &libinf;

			while (ExNext(dir,fib))
				if (*next = ReadFD(fib->fib_FileName))
					next = &(*next)->Next;
		}
		FreeMem(fib,sizeof(*fib));
	}

	CurrentDir(odir);

	UnLock(dir);
}

return(libinf);
}





struct LibraryInfo *ReadFD(UBYTE *name)
{
BPTR bptr;
struct FileInfoBlock *fib;
ULONG actuallen = 0;
UBYTE *filebuffer;
struct LibraryInfo *lib = 0;


/* only names ending in '_lib.fd' allowed */
if (!strstr(name,"_lib.fd")) return(0);


if (fib = AllocMem(sizeof(*fib),MEMF_CLEAR | MEMF_PUBLIC))
{
	if (bptr = Lock(name,ACCESS_READ))
	{
		Examine(bptr,fib);
		UnLock(bptr);
		actuallen = fib->fib_Size;
	}
	FreeMem(fib,(ULONG)sizeof(*fib));
}

if (!actuallen) return(0);

if (!(filebuffer = AllocMem(actuallen,MEMF_PUBLIC)))
	return(0);


if (bptr = Open(name,MODE_OLDFILE))
{
	if (Read(bptr,filebuffer,actuallen) == actuallen)
	{
		filebuffer[actuallen - 1] = 0;	/* NULL terminate the buffer */

		if (lib = ProcessFD(filebuffer))
		{
			strcpy(lib->LibraryName,name);
			strcpy(strstr(lib->LibraryName,"_lib.fd"),".library");
		}
	}

	Close(bptr);
}

FreeMem(filebuffer,actuallen);

return(lib);
}





/* buffer punta a un buffer contenente il file .fd che verra` tradotto e */
/* memorizzato in una struttura LibraryInfo, allocata dinamicamente. */
/* buffer deve essere NULL terminated */
struct LibraryInfo *ProcessFD(UBYTE *buffer)
{
UBYTE *curr;
WORD j;
struct LibraryInfo *lib = 0;
WORD offset;
UBYTE *start = 0;
ULONG filelen = 0;


do
{
	curr = buffer;
	offset = 0;

	while (*curr)
	{
		if (*curr != '*' && *curr != '\n')
		{
			if (*curr == '#')
			{
				if (!strncmp(curr,"##bias",6))
					offset = atoi(curr + 7) / 6;
			}
			else
			{
				j = strstr(curr,"(") - curr;
				if (j)
				{
					if (lib)
					{
						lib->FunctionName[offset] = start;

						curr[j] = 0;
						strcpy(start,curr);
						curr += j + 1;
						start += j + 1;
					}
					else filelen += j + 1;

					offset++;
				}
			}
		}

		/* position at the beginning of next line */
		while (*(curr++) != '\n' && *curr);
	}

	/* if end of second loop, exit */
	if (lib) break;

	filelen += sizeof(struct LibraryInfo) + (offset - 1) * sizeof(UBYTE *);

	if (lib = AllocMem(filelen,MEMF_CLEAR))
	{
		lib->TotalLen = filelen;
		lib->Entries = offset;

		/* put address of buffer where to copy the names in start, and repeat the loop */
		start = (UBYTE *)&lib->FunctionName[lib->Entries];
	}
} while(lib);	/* if AllocMem() failed, exit the loop */

return(lib);
}





struct LibraryInfo *FindLibraryInfo(struct LibraryInfo *list,UBYTE *name)
{
struct LibraryInfo *libinf = list;

while (libinf)
{
	if (!strcmp(libinf->LibraryName,name)) return(libinf);

	libinf = libinf->Next;
}

return(0);
}







struct IntuiText reqbody =
{
	AUTOFRONTPEN,AUTOBACKPEN,AUTODRAWMODE,
	15,5,
	NULL,
	NULL,
	NULL
};

struct IntuiText reqok =
{
	AUTOFRONTPEN,AUTOBACKPEN,AUTODRAWMODE,
	AUTOLEFTEDGE,AUTOTOPEDGE,
	NULL,
	"Ok",
	NULL
};


VOID message(UBYTE *text)
{
BPTR outp;
extern struct WBStartup *WBenchMsg;

if (WBenchMsg)
{
	reqbody.IText = text;
	AutoRequest(NULL,&reqbody,NULL,&reqok,NULL,NULL,IntuiTextLength(&reqbody) + 52L,52L);
}
else
{
	outp = Output();
	Write(outp,text,strlen(text));
	Write(outp,"\n",1L);
}
}




VOID cleanup(WORD code)
{
WORD k;
struct LibraryInfo *next;
extern struct Window *window;
extern struct Gadget *scrollbar[2],*hidden[100];
extern WORD NumberOfGadgets;
extern struct LibraryInfo *LibInfoList;
extern struct MsgPort *ManagerPort;
extern struct GfxBase *GfxBase;
extern struct IntuitionBase *IntuitionBase;


if (window) CloseWindow(window);

FreeGadget(scrollbar[0]);
FreeGadget(scrollbar[1]);
for (k = 0;k < NumberOfGadgets;k++) FreeGadget(hidden[k]);

if (LibInfoList)
{
	do
	{
		next = LibInfoList->Next;
		FreeMem(LibInfoList,LibInfoList->TotalLen);
		LibInfoList = next;
	} while (LibInfoList);
}

if (ManagerPort) DeletePort(ManagerPort);

if (IntuitionBase) CloseLibrary((struct Library *)IntuitionBase);
if (GfxBase) CloseLibrary((struct Library *)GfxBase);

exit(code);
}




VOID exit(int code)
{
extern struct WBStartup *WBenchMsg;
extern long _savsp;
extern struct DOSBase *DOSBase;


if (WBenchMsg)
{
	Forbid();
	ReplyMsg((struct Message *)WBenchMsg);
}

CloseLibrary((struct Library *)DOSBase);

{
#asm
	moveq	#0,d0
	move.w	%%code,d0		;pick up return exit code
	move.l	__savsp#,sp		;get back original stack pointer
	rts					;and exit
#endasm
}
}
